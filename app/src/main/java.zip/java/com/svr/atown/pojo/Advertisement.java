package com.svr.atown.pojo;

public class Advertisement {

    String firstAdv;
    String secondAdv;
    String thirdAdv;
    String fourthAdv;
    String fifthAdv;

    public String getFourthAdv() {
        return fourthAdv;
    }

    public void setFourthAdv(String fourthAdv) {
        this.fourthAdv = fourthAdv;
    }

    public String getFifthAdv() {
        return fifthAdv;
    }

    public void setFifthAdv(String fifthAdv) {
        this.fifthAdv = fifthAdv;
    }

    public String getFirstAdv() {
        return firstAdv;
    }

    public void setFirstAdv(String firstAdv) {
        this.firstAdv = firstAdv;
    }

    public String getSecondAdv() {
        return secondAdv;
    }

    public void setSecondAdv(String secondAdv) {
        this.secondAdv = secondAdv;
    }

    public String getThirdAdv() {
        return thirdAdv;
    }

    public void setThirdAdv(String thirdAdv) {
        this.thirdAdv = thirdAdv;
    }
}
